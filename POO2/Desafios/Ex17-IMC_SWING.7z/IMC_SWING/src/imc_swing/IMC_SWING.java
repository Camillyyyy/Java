package imc_swing;

public class IMC_SWING {

    public static void main(String[] args) {
    }
    
}
