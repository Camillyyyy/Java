package questao2_prov20.pkg04;

import java.util.Scanner;

public class Questao2_Prov2004 {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        //variaveis
        Double preco;
        int qnt;
        String nome;
        Double comi = 0.10;
        
        System.out.print("====================================");
        System.out.print("\nNome do vendedor: ");
        nome=input.next();
        
        
        System.out.print("\nInforme o preço do produto: ");
        preco=input.nextDouble();
                
        System.out.print("\nInforme a quantidade do produto: ");
        qnt=input.nextInt();
        System.out.print("====================================");
        
        
        Double calc=((qnt*preco)+(comi*qnt));
        
        
        System.out.println("\nO vendedor "+nome+" finalizou uma venda que deu: "+calc+"R$.");
        
        
        
        
        
        
        
        
        
    }
    
}
