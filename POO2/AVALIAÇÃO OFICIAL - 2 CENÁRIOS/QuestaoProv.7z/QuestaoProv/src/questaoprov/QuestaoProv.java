package questaoprov;

public class QuestaoProv {

    public static void main(String[] args) {
        
    }
    
}
