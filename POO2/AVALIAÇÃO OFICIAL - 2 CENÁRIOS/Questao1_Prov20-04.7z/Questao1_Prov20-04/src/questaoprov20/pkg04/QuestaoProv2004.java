package questaoprov20.pkg04;

import java.util.Scanner;

public class QuestaoProv2004 {

//implemente um programa em Java que leia o código de um item e a quantidade deste item. A Seguir, calcule e mostre o valor da conta a pagar.
    
    public static void main(String[] args) {
        int cod;
        Double calc, cod1;
        
        Scanner input=new Scanner(System.in);
        
        System.out.println("=====================================");
        System.out.println("| CÓDIO | ESPECIFICAÇÃO   | PREÇO   |");
        System.out.println("|-----------------------------------|");
        System.out.println("|   1   | CACHORRO QUENTE | 4,00 R$ |");
        System.out.println("|   2   |     X-SALDA     | 4,50 R$ |");
        System.out.println("|   3   |     X-BACON     | 5,00 R$ |");
        System.out.println("|   4   | TORRADA SIMPLES | 2,00 R$ |");
        System.out.println("|   5   |   REFRIGERANTE  | 1,50 R$ |");
        System.out.println("=====================================");

                
        System.out.println("\nDigite o código do seu item: ");
        cod=input.nextInt();
        
        System.out.println("\nDigite a quantidade do seu item: ");
        cod1=input.nextDouble();
        
        //hot dog
        if (cod==1){
            calc=(4*cod1);
            System.out.println("Valor total: "+calc);
        }
        
        //x salada
        if (cod==2){
            calc=(4.50*cod1);
            System.out.println("Valor total: "+calc);
        }
        
        //x bacon
        if (cod==3){
            calc=(5*cod1);
            System.out.println("Valor total: "+calc);
        }
        
        
        //torrada
        if (cod==4){
            calc=(2*cod1);
            System.out.println("Valor total: "+calc);
        }
        
        //refri
        if (cod==5){
            calc=(1.50*cod1);
            System.out.println("Valor total: "+calc);
        }
            
        
        
        
    }
    
}
