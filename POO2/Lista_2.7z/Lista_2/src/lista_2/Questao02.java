package lista_2;
import java.util.Scanner;

public class Questao02 {
    public static void main(String[] args){
     Scanner input = new Scanner(System.in);
     int num, num2;
     
     System.out.print("Digite o valor X: ");
     num=input.nextInt();
     
     System.out.print("\nDigite o valor y: ");
     num2=input.nextInt();
     
     if (num>num2){
        System.out.print("\nO maior é o: "+num);
    }
     else{
             System.out.print("\nO maior é o: "+num2);
    }
    }
}
