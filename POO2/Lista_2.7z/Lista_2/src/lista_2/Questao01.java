package lista_2;
import java.util.Scanner;

public class Questao01 {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int num;
        
        System.out.print("Digite um número: ");
        num=input.nextInt();
        
        
        if (num > 10){
            System.out.println("Maior que '10'");
        }
        else{
            System.out.println(num);                  
        }
    }
    
}
