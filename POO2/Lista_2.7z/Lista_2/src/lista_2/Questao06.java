package lista_2;
import java.util.Scanner;

public class Questao06 {
    public static void main(String[] args){
        Scanner input=new Scanner(System.in);
        int n;
        
        System.out.print("Digite um número de 1 ao 5: ");
        n=input.nextInt();
        
        if(n==1){
            System.out.println("UM");
        }else if (n==2){
            System.out.println("DOIS");
        } else if (n==3){
            System.out.println("TRES");
        }else if (n==4){
            System.out.println("QUATRO");
        }else if (n==5){
            System.out.println("CINCO");
        }
        
        
 }
}
