package lista_2;
import java.util.Scanner;

//Faça um programa que receba um número e mostre uma mensagem caso este número seja maior que 80, menor que 25 ou igual a 40

public class Questao05 {
    public static void main(String[] args){
        Scanner input=new Scanner(System.in); 
        int num;
        
        System.out.print("Digite um número: ");
        num=input.nextInt();
        
        if (num > 80){
            System.out.println(num + " é maior que 80");
        } else if (num < 25){
            System.out.println(num + " é menor que 25");
        } else if (num == 40){
            System.out.println("Você digitou 40");
        }
    
    }

}
