package lista_2;
import java.util.Scanner;

public class Questao03 {
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);        
        int num;

        System.out.println("Digite um valor para verificar se está entre 100 e 200: ");
        num = input.nextInt();
        //teclado.close();
    
    if(num >= 100 && num <= 200) { 
        System.out.println("O valor está está entre 100 e 200."); 
    }
    else {
        System.out.println("O valor não está.");
    }
    
        
    
 }
}
