package lista_2;
import java.util.Scanner;
//Faça um algoritmo que receba o preço de custo e o preço de venda de um produto. Mostre como resultado se houve lucro, prejuízo ou empate para cada produto. Informe média de preço de custo e do preço de venda.
public class QUESTAO07 {
    public static void main(String[] args){
        Scanner input=new Scanner(System.in);
        double custo, venda, prod;
        
        System.out.print("Digite o preço do custo:"); //preço de custo
        custo=input.nextDouble();
        System.out.print("Digite o preço da venda: "); //preço de venda
        venda=input.nextDouble();
        
        prod=(venda-custo); 
        
        if(venda>custo){
        System.out.println("\nHouve lucro na venda de: "+prod);
    }
        else if(venda<custo){
        System.out.println("\nHouve prejuizo na venda de: "+prod);
    }
        else if(venda==custo){
        System.out.println("\nHouve empate na venda");
    }
        
        
        
 }
}
