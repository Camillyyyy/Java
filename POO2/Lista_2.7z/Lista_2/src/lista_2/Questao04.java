package lista_2;
import java.util.Scanner;

public class Questao04 {
    public static void main(String[] args){
    String nome; 
    double nota1,nota2,nota3,media;
        
    Scanner input=new Scanner(System.in); 
       
    System.out.print("Nome do cursista: "); 
    nome = input.next(); 
    System.out.print("\nNota da 1° prova: "); 
    nota1 = input.nextDouble(); 
    System.out.print("\nNota da 2° prova: "); 
    nota2 = input.nextDouble(); 
    System.out.print("\nNota da 3° prova: ");
    nota3 = input.nextDouble(); 
               
    media = ((nota1+nota2+nota3)/3);        
    //aprovado (media >= 7), Reprovado (media <= 5) e Recuperação (media entre 5.1 a 6.9).
    
    if(media>=7){
        System.out.printf("\n\nCursista: "+nome+"\nEstado: "+media+" APROVADO");
    }
    
    else if(media >= 5.1 && media <= 6.9){
        System.out.printf("\n\nCursista: "+nome+"\nEstado: "+media+" RECUPERAÇÃO");
    }
    
    else{
        System.out.printf("\n\nCursista: "+nome+"\nEstado: "+media+" REPROVADO");
    }




//System.out.printf("\nO alnuno: "+nome+", teve uma média de: "+media);
    }
}
