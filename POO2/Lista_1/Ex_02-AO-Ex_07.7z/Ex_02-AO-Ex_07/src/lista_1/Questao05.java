package lista_1;
import java.util.Scanner;

public class Questao05 {
    public static void main(String args[]){ 
     Scanner input = new Scanner(System.in); 
 
     double valorProd, valorPrest;
     int parcelas = 5; 
 
     System.out.print("Digite o valor da compra: " ); 
     valorProd=input.nextDouble(); 
 
     valorPrest=(valorProd/parcelas); 
 
     System.out.print("O valor das 5 parcelas ficou de: "+valorPrest+" R$"); 
 }   
}
