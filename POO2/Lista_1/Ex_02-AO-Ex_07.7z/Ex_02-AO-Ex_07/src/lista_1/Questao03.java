package lista_1;
import java.util.Scanner;
public class Questao03 {
    public static void main(String[] args){
     Scanner input=new Scanner(System.in); 
     double real, dolar, cota;
   
    System.out.print("Digite o valor em dolar:" ); 
    dolar = input.nextDouble(); 
 
    System.out.print("\nDigite o valor da cotação do dolar:" ); 
    cota = input.nextDouble(); 
 
    real=(dolar*cota); 
 
    System.out.printf("Valor em real será de: " +real+ " R$");
    }
}
