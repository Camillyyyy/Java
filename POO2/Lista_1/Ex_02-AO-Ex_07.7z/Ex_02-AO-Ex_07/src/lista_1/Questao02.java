package lista_1;
import java.util.Scanner;
public class Questao02 {

    public static void main(String[] args) {
    String nome; 
    double nota1,nota2,nota3,media;
        
    Scanner input=new Scanner(System.in); 
       
    System.out.print("Nome do Aluno: "); 
    nome = input.next(); 
    System.out.print("\nNota da 1° prova: "); 
    nota1 = input.nextDouble(); 
    System.out.print("\nNota da 2° prova: "); 
    nota2 = input.nextDouble(); 
    System.out.print("\nNota da 3° prova: ");
    nota3 = input.nextDouble(); 
               
    media = ((nota1+nota2+nota3)/3);        
    
    System.out.printf("\nO alnuno: "+nome+", teve uma média de: "+media); 
         
    }        
}
