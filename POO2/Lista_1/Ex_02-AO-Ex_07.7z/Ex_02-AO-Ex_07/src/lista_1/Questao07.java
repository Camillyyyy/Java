package lista_1;
import java.util.Scanner;

public class Questao07 {
  public static void main(String args[]){ 
     Scanner input = new Scanner(System.in); 
     double custo, acres, venda;
 
     System.out.print("Digite o preço de custo do produto: "); 
     custo = input.nextDouble(); 
 
     System.out.print("\nDigite a porcentagem de acrescimo: "); 
     acres = input.nextDouble(); 
 
     venda =(((custo*acres)/100)+custo); 
 
     System.out.printf("\nO valor de venda é: "+venda+"R$");  
 }
}
  
