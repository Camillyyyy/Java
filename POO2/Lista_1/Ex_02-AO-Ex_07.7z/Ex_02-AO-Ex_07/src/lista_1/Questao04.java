package lista_1;
import java.util.Scanner;

public class Questao04 {
    public static void main(String[] args){
     Scanner input=new Scanner(System.in);
     double valor_depo, rend, juro; 
 
     System.out.print("Digite o valor do deposito:" ); 
     valor_depo = input.nextDouble(); 
     
     juro =((valor_depo*0.70)/100);
     rend = juro + valor_depo; 
 
     System.out.print("O rendimento no mês foi de: "+rend+"R$" );
  }
}
