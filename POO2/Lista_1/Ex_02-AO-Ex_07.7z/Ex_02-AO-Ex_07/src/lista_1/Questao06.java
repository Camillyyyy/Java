package lista_1;
import java.util.Scanner;

public class Questao06 {
    public static void main(String args[]){
     Scanner input=new Scanner(System.in);
     int a, b, aux;

     System.out.print("Digite o número 'A': ");
     a=input.nextInt();

     System.out.print("\nDigite o número 'B': ");
     b=input.nextInt();

     //troca com aux
     a=b;
     aux=a;
     b=aux;

     System.out.println("O valor trocado será A: "+a+"\nB: "+b);
    }
}
